//YOUR FIREBASE LINKS
const firebaseConfig = {
      apiKey: "AIzaSyA9jVJ8Mk0FvTnCwN5oEBDOvGahwsXChek",
      authDomain: "kwitter-5d51c.firebaseapp.com",
      databaseURL: "https://kwitter-5d51c-default-rtdb.firebaseio.com",
      projectId: "kwitter-5d51c",
      storageBucket: "kwitter-5d51c.appspot.com",
      messagingSenderId: "353842391295",
      appId: "1:353842391295:web:0a5c5f0be01ff1a2d2c4ca"
    };

firebase.initializeApp(firebaseConfig);

user_name = localStorage.getItem("user_name");
room_name = localStorage.getItem("room_name");

function send() {
     msg = document.getElementById("msg").value;
     firebase.database().ref(room_name).push({
      name : user_name,
      message : msg,
      likes : 0
     });

     document.getElementById("msg").innerHTML = "";
}

function getData() { firebase.database().ref("/"+room_name).on('value', function(snapshot) { document.getElementById("output").innerHTML = ""; snapshot.forEach(function(childSnapshot) { childKey  = childSnapshot.key; childData = childSnapshot.val(); if(childKey != "purpose") {
         firebase_message_id = childKey;
         message_data = childData;
//Start code
console.log("Room Name - "+ Room_names);
row = "<div class='room_name' id="+ Room_names + "onclick='redirectToRoomName(this.id)'> #" +Room_names + "</div><hr>";
document.getElementById("output").innerHTML = row;
//End code
      } });  }); }
getData();
